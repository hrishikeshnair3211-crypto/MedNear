# Android / Google Play preparation

This is an Android packaging scaffold, not a signed release build or a Play-ready AAB.

## Prepare the Android project
1. Install a current Node.js LTS release and Android Studio on a development computer.
2. In this folder, run `npm install`.
3. Run `npm run android:add` once to generate the native Android project.
4. Open the generated `android/` folder in Android Studio.
5. Set `compileSdk` and `targetSdk` to 36 or higher in the generated Gradle configuration, then resolve any plugin compatibility issues.
6. Test on physical Android devices, including location denied, location unavailable, slow network, no network, small screens, TalkBack and Hindi rendering.
7. Create a release signing key and build a signed Android App Bundle (AAB) in Android Studio. Keep signing credentials private and backed up.
8. Complete Play Console app content, Data safety, privacy policy URL, app access, target audience, content rating, store listing, screenshots, icon and testing track.
9. Submit for review only after legal, privacy, security, data quality and emergency-information checks are complete.

## Important release gates
- Google Play's current new-app target requirement from 31 August 2026 is Android 16 / API 36 or higher. Verify again in Play Console before submission.
- This app requests foreground location only when the user taps the location button. Do not add background location unless a core feature genuinely needs it and Google approves the declaration.
- The current OpenStreetMap public Nominatim and Overpass endpoints are suitable for prototyping, not guaranteed production infrastructure. For global launch, arrange a compliant, reliable provider or host your own service; observe usage policies and attribution.
- Do not claim worldwide coverage until facility completeness has been measured country by country.
- Do not show guessed hospital phone numbers, emergency numbers, opening hours, ambulance availability or bed availability.
- No emergency dispatch integration exists. Calling a hospital uses the phone dialler; MedNear does not contact dispatch centers.
- Publish the completed privacy policy and verify every statement against the final binary and all third-party SDKs.
- Have an adult developer/account owner manage Play Console registration, legal declarations, signing and publication.
