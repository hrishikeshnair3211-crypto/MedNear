# MedNear — Play Store listing draft

**App name:** MedNear — Nearby Hospitals  
**Short description:** Find nearby hospitals and healthcare facilities on a map.  
**Full description:**

Find healthcare facilities around your selected location with MedNear.

Features:
- Search for hospitals, clinics and doctors/health centres.
- Use your current location (with permission) or search by area, landmark, city or postal code.
- View mapped facility locations and approximate distances.
- Open directions in your preferred maps app.
- Call a facility when a phone number is listed.
- Switch between English and Hindi.

**Important:** Facility information is sourced from community-mapped OpenStreetMap data and may be incomplete or outdated. MedNear does not verify hospital quality, live bed availability, doctor rosters or opening status. Contact the facility to confirm information before travelling. MedNear is not an emergency dispatch service and does not provide medical advice. Emergency numbers vary by country; use the official local emergency service.

**Category:** Medical (confirm the best Play category during submission)  
**Developer contact:** [Add monitored support email]  
**Privacy policy URL:** [Publish the completed privacy policy at a stable HTTPS URL]  
**Countries:** Worldwide rollout should be staged; confirm local data coverage, translations, emergency information and legal obligations before enabling each country.
