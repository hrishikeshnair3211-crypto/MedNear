# MedNear release status — 4 November 2026

## Included in this preparation bundle
- Worldwide location/locality search prototype using OpenStreetMap data
- English/Hindi interface toggle for the primary navigation and search controls
- Hospital/clinic/doctor listing, mapped phone number links and directions
- Country-aware emergency safety messaging (no guessed global emergency number; no dispatch claim)
- Capacitor Android packaging configuration
- Privacy policy draft, Play Store listing draft and release checklist

## Not yet completed
- No generated `android/` native project or signed `.aab`
- No Play Console account, app registration, review or publication
- No public HTTPS privacy-policy URL; the draft contains developer placeholders
- No independent verification of hospital names, addresses, phone numbers, emergency services or facility availability
- No global emergency-number directory or dispatch-center integration
- No production data-provider agreement or service-level guarantee
- No country-by-country legal review, localization review or security audit

The app must not be marketed as an ambulance-dispatch system or as a verified global hospital database until those systems and data have been implemented, tested and independently validated.

## Free launch path
The website can be hosted free on GitHub Pages. Android build tooling (Node.js, Capacitor and Android Studio) can be used without a software licence fee. Google Play developer registration is paid; see `FREE_LAUNCH_GUIDE.md`.
