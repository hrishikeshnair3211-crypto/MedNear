# MedNear — worldwide prototype

Responsive hospital/clinic finder website with an installable PWA shell, English/Hindi interface toggle, locality search, location-based nearby search, mapped facility listings, phone links when a number is mapped, and directions.

## Run locally
Serve this directory on localhost or HTTPS (for example `python -m http.server 8000`) and open it in a browser. Location permission is requested only after the user taps the location button.

## Prototype data
The app uses community-mapped OpenStreetMap data via public Nominatim and Overpass services. These public endpoints are not a production-grade global service. Data may be missing, stale or inaccurate. Phone numbers are displayed only when mapped; the app never invents them.

## Emergency safety
Emergency numbers vary by country and region. The interface gives general guidance only. It does not automatically call an assumed global number and does not dispatch ambulances. The app does not verify emergency availability.

## Production status
This package includes an Android/Capacitor setup scaffold, Play Store listing draft, privacy policy draft and release checklist. It does **not** contain a generated Android Studio project, signed AAB, Play Console submission, or a final legally reviewed privacy policy. See `ANDROID_PLAY_STORE_PREP.md`, `FREE_LAUNCH_GUIDE.md` and `privacy-policy-draft.html`.

## Free launch options
See `FREE_LAUNCH_GUIDE.md` for GitHub Pages hosting and local Capacitor/Android Studio build steps.
